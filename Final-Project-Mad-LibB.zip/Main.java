import java.io.*;//necessary imports 
import java.util.*;
class Main {//beginning of the main class
  public static void main(String[] args) {//beginning of the main method
    Scanner kbReader = new Scanner(System.in);//two generic scanners to take in all input
    Scanner kbInt= new Scanner (System.in);
    System.out.println("Welcome to the Madlib generation game! In this game you fill in MadLibs and decide which team's MadLib was funniest at the end of each round. There are 5 rounds total and this game can only be played with 2-4 teams! ");//welcome
    System.out.println("~~~~~~~~~~Please enter the amount of teams you would like (2-4).~~~~~~~~~~");
    int teamChoice = kbReader.nextInt();//take input
    RandomGenerate teamOne;//declare 4 objects 
    RandomGenerate teamTwo;
    RandomGenerate teamThree;
    RandomGenerate teamFour;
    int winner=0;//point tracking
    Points object=new Points();//object for points class
    object.arrayLength(teamChoice);//calls arrayLength to set the amount of teams in points class
    String enter;//used for press enter comand

    for (int round=1;round<6;round++){//as long as less that 6 rounds have been played, the loop will run
    for (int t = 0; t == 0;) {//in case wrong number is entered
      switch (teamChoice) {//decision based on number of teams
        case 2://first case 
          teamOne = new RandomGenerate();//initialize as many objects as necessary
          teamTwo = new RandomGenerate();
          t++;
          System.out.println("Round "+round);//rounds begin
          System.out.println("Team One:");
          teamOne.generation();//first team fills a madlib
          System.out.println("Team Two:");
          teamTwo.generation();//second team fills a madlib
          break;//break out of switch
        case 3://second case
          teamOne = new RandomGenerate();//initialize as many objects as necessary
          teamTwo = new RandomGenerate();
          teamThree = new RandomGenerate();
          t++;
          System.out.println("Round "+round);//rounds begin
          System.out.println("Team One:");
          teamOne.generation();//first team fills a madlib
          System.out.println("Team Two:");
          teamTwo.generation();//second team fills a madlib
          System.out.println("Team Three:");
          teamThree.generation();//third team fills a madlib
          break;//break out of switch
        case 4:// third case
          teamOne = new RandomGenerate();//initialize as many objects as necessary
          teamTwo = new RandomGenerate();
          teamThree = new RandomGenerate();
          teamFour = new RandomGenerate();
          t++;
          System.out.println("Round "+round);//rounds begin
          System.out.println("Team One:");
          teamOne.generation();//first team fills a madlib
          System.out.println("Team Two:");
          teamTwo.generation();//second team fills a madlib
          enter= kbReader.nextLine();
          System.out.println("Team Three:");
          teamThree.generation();//third team fills a madlib
          System.out.println("Team Four:");
          teamFour.generation();//fourth team fills a madlib
          break;//break out of case
        default:
          System.out.println("~~~~~~~~~~Sorry please re-enter a number between 2-4~~~~~~~~~~");//in case of incorrect input
          teamChoice = kbReader.nextInt();//the variable is reassigned
      }// end of switch statement
    }// end of inner for loop
      System.out.println("~~~~~~~~~~Which team would you like to win round "+round+"?~~~~~~~~~~");//decide winner of the round
      while(true){
      try{
      System.out.println("Please enter a number.(Ex.1)");
      winner=kbInt.nextInt();
      object.pointWinner(winner);// winner gets a point added to their score
        break;
      }
      catch(IndexOutOfBoundsException e){
      System.out.println(e+" Please enter one of the team's numbers.");
      }
      }
    }//end of outer for loop

    object.print();// the final winner is printed with their score
  }
}