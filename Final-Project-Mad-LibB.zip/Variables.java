import java.io.*;//imports required for the Scanner objects
import java.util.*;
class Variables {

  //State variables which woill be used in each sub class which extends variables. This class is mainly to store the variables neccessary
  
  //celebrities
  String celebrityOne;
  String celebrityTwo;
  
  //nouns
  String noun;
  String nounTwo;
  String nounThree;
  String nounFour;
  String nounPlur;
  String nounPlurTwo;
  String nounPlurThree;
  String place;
  
  //adjectives
  String adj;
  String adjTwo;
  String adjThree;
  String adjFour;
  
  //verbs
  String verb;
  String verbTwo;
  String adverb;
  String verbPast;

//food
  String food;
  String foodPlur;
  String typeOFliquid;
  String liquid;
  String foodTwo;
  
  //numbers
  double num;
  double numTwo;
  
  //miscellaneous
  String sillyWord;
  String animal;
  String maleName;
  String nationality;
  String name;
  String shapes;
  String bodyPart;
  String enter;

  // generic scanners
  Scanner kbReader = new Scanner(System.in);
  Scanner kbDouble = new Scanner(System.in);
}

interface Outline{//interface to set requirements for each madlib
  public void assignment();//method to assign values to the variables
  public void print();//prints full madlib
}