import java.util.Random;//import to generate random choice

public class RandomGenerate {// beginning of class
  Random madLib = new Random();//creating Random class object 

  public void generation() {//method generation begins

    int high=5;//setting limits
    int low=1;
    
    int num = madLib.nextInt(high+low)+low;//generating random number
    if (num == 1) {//depending on what random number is picked, the corrseponding madlib class is called (and methods)
      zAlexanderTheGreat obj=new zAlexanderTheGreat();
      obj.assignment();
      obj.print();
    } 
    else if (num == 2) {
      zAStrangeTale obj=new zAStrangeTale();
      obj.assignment();
      obj.print();
    } 
    else if (num == 3) {
      zBakingTips obj=new zBakingTips();
      obj.assignment();
      obj.print();
    }
    else if (num == 4) {
      zNewsbreak obj=new zNewsbreak();
      obj.assignment();
      obj.print();
    } 
    else if (num == 5) {
      ZombieCamp obj=new ZombieCamp();
      obj.assignment();
      obj.print();
    } 
    else if (num == 6) {
      zPizza obj=new zPizza();
      obj.assignment();
      obj.print();
    }

  }// end of method generation
}// end of class Randomgenerate