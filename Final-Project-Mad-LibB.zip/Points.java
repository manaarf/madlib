import java.util.ArrayList;
public class Points{
    ArrayList<String> teams = new ArrayList<String>();//two arraylists to store all the information necessary to assign points to the winning teams
    ArrayList<Integer> points = new ArrayList<Integer>();


  public void arrayLength(int teamChoice){//this method alters the arrayLists to be the size necessary
    switch (teamChoice){
    //depending on what teamChoice is, the corresponding amount of indexes will be added to both of the previous ArrayLists contaning the correct values which would be the team number and the amount of points which would be 0 for all.
    case 2:
      teams.add("Team One");
      points.add(0);
      teams.add("Team Two");
      points.add(0);
      break;
    case 3:
      teams.add("Team One");
      points.add(0);
      teams.add("Team Two");
      points.add(0);
      teams.add("Team Three");
      points.add(0);
      break;
    case 4: 
      teams.add("Team One");
      points.add(0);
      teams.add("Team Two");
      points.add(0);
      teams.add("Team Three");
      points.add(0);
      teams.add("Team Four");
      points.add(0);
      break;
    }// end of switch 
  }//end of method


  public void pointWinner(int winner){//method pointWinner 
    int index=winner-1;// creating a variable to use to assign values in the two ArrayLists since the index is one less than the inputted number
    points.set(index,(points.get(index)+1));//changing the teams points to add one to the pre-existing value
  }//end of method


  public void print(){// method print begins

    
    int length=points.size();//get length of the array
    int max = points.get(0);//first value inside
        for (int num = 1; num < length; num++) {// iterate through every value
            if (max < points.get(num))//if max is less than the value being being iterated through, max becomes said value
            {max = points.get(num);}
        }
        int champions= points.indexOf(max);//gets index of the largest value inside the array

    System.out.println("The winner is "+teams.get(champions)+" with "+points.get(champions)+" points!!");//print line with the winner and their amount of points
    //System.out.println("The winner is "+teams.get(champions)+" with "+points.get(champions)+" points!!");
  }//end of print method
}// end of Points class
//https://www.geeksforgeeks.org/finding-maximum-element-of-java-arraylist/