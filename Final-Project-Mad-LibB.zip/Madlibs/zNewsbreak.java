public class zNewsbreak extends Variables implements Outline{// class begins

  
  

  public void assignment() {// method assignment begins
    System.out.println("Press enter to begin the Mad Lib Newsbreak!");
    enter = kbReader.nextLine();

    System.out.print("Noun: ");// takes in the input for each
    noun = kbReader.nextLine();

    System.out.print("Plural Noun: ");//same here and so forth
    nounPlur = kbReader.nextLine();

    System.out.print("Adjective: ");
    adj = kbReader.nextLine();

    System.out.print("Verb: ");
    verb = kbReader.nextLine();

    System.out.print("Adjective: ");
    adjTwo = kbReader.nextLine();

    System.out.print("Place: ");
    place = kbReader.nextLine();

    System.out.print("Animal: ");
    animal = kbReader.nextLine();

    System.out.print("Adjective: ");
    adjThree = kbReader.nextLine();

    System.out.print("Body Part: ");
    bodyPart = kbReader.nextLine();

    System.out.print("Food: ");
    food = kbReader.nextLine();

    System.out.print("Verb in Past Tense: ");
    verbPast = kbReader.nextLine();

    System.out.print("Food: ");
    food = kbReader.nextLine();

    System.out.print("Male Name: ");
    maleName = kbReader.nextLine();

    System.out.print("Plural Noun: ");
    nounPlurTwo = kbDouble.nextLine();

    System.out.print("Plural Noun: ");
    nounPlurThree = kbDouble.nextLine();

    System.out.print("Number: ");
    num = kbDouble.nextDouble();
  }// method assignment ends

  public void print() {// method print begins
//prints entire madlib with variables added
    System.out.println("The prime minister passed his physical " + noun + " with flying " + nounPlur
        + " this morning. Doctors gave him a " + adj + " bill of health, but advised him to " + verb
        + " at least twenty minutes a day and to eat less " + adjTwo + " food.");

    System.out
        .println("At the " + place + " zoo, a five-hundred pound " + animal + " reached out and grabbed a woman's "
            + adjThree + " camera right out of her " + bodyPart + ".When she tried to take his picture eating a " + food
            + ". The " + animal + " then " + verbPast + " the camera.");

    System.out.println("Sometimes it doesn't pay to diet. Popular comedian " + maleName + ", who's lost more than "
        + num + " pounds,was virtually caught with his " + nounPlurTwo
        + " down when his pants fell to the floor as he performed in front of an audience of five hundred enthusiastic "
        + nounPlurThree + ".");
    System.out.println("~~~~~~~~~~Press enter to continue.~~~~~~~~~~");
    enter= kbReader.nextLine();
    System.out.print("\033[H\033[2J");// clears console when enter is pressed
    System.out.flush();
  }// metod print ends
}//class ends