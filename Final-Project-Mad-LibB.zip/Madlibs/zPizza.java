public class zPizza extends Variables implements Outline{// class begins

 

  public void assignment() {// method assignment begins
    
    System.out.println("Press enter to begin the Mad Lib Pizza!");
    enter = kbReader.nextLine();

    System.out.print("Adjective: ");// takes in the input for each
    adj = kbReader.nextLine();

    System.out.print("Adjective: ");//same here and so forth
    adjTwo = kbReader.nextLine();

    System.out.print("Adjective: ");
    adjThree = kbReader.nextLine();

    System.out.print("Adjective: ");
    adjFour = kbReader.nextLine();

    System.out.print("Nationality: ");
    nationality = kbReader.nextLine();

    System.out.print("Name: ");
    name = kbReader.nextLine();

    System.out.print("Noun: ");
    noun = kbReader.nextLine();

    System.out.print("Noun: ");
    nounTwo = kbReader.nextLine();

    System.out.print("Noun: ");
    nounThree = kbReader.nextLine();

    System.out.print("Plural Noun: ");
    nounPlur = kbReader.nextLine();

    System.out.print("Plural Shape: ");
    shapes = kbReader.nextLine();

    System.out.print("Food: ");
    food = kbReader.nextLine();

    System.out.print("Food: ");
    foodTwo = kbReader.nextLine();

    System.out.print("Number: ");
    num = kbDouble.nextDouble();

    System.out.print("Number: ");
    numTwo = kbDouble.nextDouble();
  }// method assignment ends

  public void print() {// method print begins
    //prints entire madlib with variables added
    System.out.println("Pizza was invented by a " + adj + " " + nationality + " chef named " + name
        + ". To make pizza, you need to take a lump of " + noun + ", and make a thin, round " + adjTwo + " " + nounTwo
        + ", Then you cover it with " + adjThree + " sauce, " + adjFour + " cheese, and fresh chopped " + nounPlur
        + ". Next you have to bake it in a very hot " + nounThree + ". When it is done, cut into " + num + " " + shapes
        + ". Some kids like the " + food + " pizza the best, but my favourite is the " + foodTwo
        + " pizza. If I could, I would eat pizza " + numTwo + " times a day.");
    System.out.println("~~~~~~~~~~Press enter to continue.~~~~~~~~~~");
    enter = kbReader.nextLine();
    System.out.print("\033[H\033[2J");// clears console when enter is pressed
    System.out.flush();
  }// method print ends

}// class ends