public class zAStrangeTale extends Variables implements Outline {// class begins

  
  
  public void assignment() {// method assignment begins

    System.out.println("Press enter to begin the Mad Lib A Strange Tale.");
    enter = kbReader.nextLine();

    System.out.print("Adjective: ");// takes in the input for each
    adj = kbReader.nextLine();

    System.out.print("Adjective: ");//same here and so forth
    adjTwo = kbReader.nextLine();

    System.out.print("Plural Noun: ");
    nounPlur = kbReader.nextLine();

    System.out.print("Plural Noun: ");
    nounPlurTwo = kbReader.nextLine();

    System.out.print("Plural Food: ");
    foodPlur = kbReader.nextLine();

    System.out.print("Noun: ");
    noun = kbReader.nextLine();

    System.out.print("Verb in Past Tense: ");
    verbPast = kbReader.nextLine();
  }// method assignment ends

  public void print() {// method print begins
    //prints entire madlib with variables added
    System.out.println("There was a/an " + adj + " lady that lived in a " + noun + ". She had so many " + nounPlur
        + ", she didnt know what to do. She gave them some " + adjTwo + " " + foodPlur + " without any " + nounPlurTwo
        + ", and " + verbPast + " as she put them to bed.");
    System.out.println("Good night. :)");
    System.out.println("~~~~~~~~~~Press enter to continue.~~~~~~~~~~");
    enter= kbReader.nextLine();
    System.out.print("\033[H\033[2J");// clears console when enter is pressed
    System.out.flush();
  }//method print ends

}//class ends