public class zAlexanderTheGreat extends Variables implements Outline {// class begins



  public void assignment() {// method assignment begins

    System.out.println("Press enter to begin the Mad Lib 'Alexander the Great'.");
    enter = kbReader.nextLine();// takes in the input for each variable

    System.out.print("Place: ");//same here and so forth
    place = kbReader.nextLine();

    System.out.print("Celebrity: ");
    celebrityOne = kbReader.nextLine();

    System.out.print("Celebrity: ");
    celebrityTwo = kbReader.nextLine();

    System.out.print("Noun: ");
    noun = kbReader.nextLine();

    System.out.print("Noun: ");
    nounTwo = kbReader.nextLine();

    System.out.print("Noun: ");
    nounThree = kbReader.nextLine();

    System.out.print("Noun: ");
    nounFour = kbReader.nextLine();

    System.out.print("Body part: ");
    bodyPart = kbReader.nextLine();

    System.out.print("Plural noun: ");
    nounPlur = kbReader.nextLine();

    System.out.print("Plural noun: ");
    nounPlurTwo = kbReader.nextLine();

    System.out.print("Silly word: ");
    sillyWord = kbReader.nextLine();

    System.out.print("Liquid: ");
    typeOFliquid = kbReader.nextLine();
  }// end of method assignment

  public void print() {// method print begins

    System.out.println(//prints entire madlib with variables added
        "In 356 B.C., Phillip of Macedonia, the ruler of a province in Northern Greece, became the father of a bouncing baby "
            + noun + " named Alexander. Alexander's teacher was Aristotle, the famous " + nounTwo
            + ". When he was twenty years old, his father was murdered by " + celebrityOne + ", after which he became "
            + nounThree + ". of all Macedonia. In 334, he invaded Persia and defeated " + celebrityTwo
            + " at the battle of " + place
            + ". Later, he won his most important victory, over Darius the Third. This made him " + nounFour + " "
            + sillyWord + " over all Persians. Then he marched to India, and many of his " + nounPlur
            + " died. After that, Alexander began drinking too much " + typeOFliquid
            + " , and at the age of 33, he died of an infection in the " + bodyPart
            + " His last words are reported to have been, 'There are no more" + nounPlurTwo + " to conquer.'");
    System.out.println("~~~~~~~~~~Press enter to continue.~~~~~~~~~~");
    enter = kbReader.nextLine();
    System.out.print("\033[H\033[2J");// clears console when enter is pressed
    System.out.flush();
  }// end of method print
}// end of class