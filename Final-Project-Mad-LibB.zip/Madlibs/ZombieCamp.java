public class ZombieCamp extends Variables implements Outline{// class begins

  

  public void assignment() {// method assignment begins

    System.out.print("Press enter to begin the Mad Lib Zombie Camp.");
    enter = kbReader.nextLine();

    System.out.print("Verb: ");// takes in the input for each
    verb = kbReader.nextLine();

    System.out.print("Verb: ");//same here and so forth
    verbTwo = kbReader.nextLine();

    System.out.print("Plural Noun: ");
    nounPlur = kbReader.nextLine();

    System.out.print("Noun: ");
    noun = kbReader.nextLine();

    System.out.print("Adjective: ");
    adj = kbReader.nextLine();

    System.out.print("Adverb: ");
    adverb = kbReader.nextLine();

    System.out.print("Number larger than 1: ");
    num = kbDouble.nextDouble();

  }// emthod assignment ends

  public void print() {// method print begins
    //prints entire madlib with variables added
    System.out.println("How well can you " + verb + "? For only " + num
        + " dollars, you can spend a week at Zombie Camp! At Zombie Camp you get to stay up all night and " + verbTwo
        + " all day. You'll get to play " + noun + " games and eat " + adj + " " + nounPlur
        + ". So get your application into our main office " + adverb + "!");
    System.out.println("~~~~~~~~~~Press enter to continue.~~~~~~~~~~");
    enter=kbReader.nextLine();
    System.out.print("\033[H\033[2J");// clears console when enter is pressed
    System.out.flush();
  }//method print ends

}//class ends